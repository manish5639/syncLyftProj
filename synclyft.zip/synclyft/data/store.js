const users = [];
const orders = [];

module.exports = { users, orders };
